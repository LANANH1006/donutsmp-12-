package com.donutlike;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.HashSet;
import java.util.Random;

/**
 * Can cu rai rac kieu DonutSMP.
 * - Map duoc chia thanh o luoi CELL x CELL. Moi o co xac suat BASE_CHANCE co 1 can cu (co dinh theo seed the gioi).
 * - Khi nguoi choi den gan (TRIGGER_DIST) thi can cu moi duoc xay (1 lan duy nhat, luu o save.baseCells).
 * - 3 kieu: WOOD (nha go nho), STONE (2 tang gach da), OBSIDIAN (ham obsidian loot xin).
 * - Moi kieu co the NGUYEN VEN hoac BI RAID (tuong thung, ruong bi lay do, mang nhen, ho bom, vun da).
 */
public class Bases {

    static final int CELL = 112;
    static final double BASE_CHANCE = 0.85;
    static final int TRIGGER_DIST = 80;

    enum Style { WOOD, STONE, OBSIDIAN }

    record Result(BlockPos pos, Style style, boolean raided) {}

    static final Item[] WOOD_LOOT = {Items.COAL, Items.BREAD, Items.ARROW, Items.COOKED_BEEF, Items.IRON_INGOT,
            Items.GOLD_INGOT, Items.TORCH, Items.ENDER_PEARL, Items.DIAMOND};
    static final Item[] STONE_LOOT = {Items.COOKED_BEEF, Items.IRON_INGOT, Items.ARROW, Items.GOLD_INGOT, Items.EXPERIENCE_BOTTLE,
            Items.EMERALD, Items.OBSIDIAN, Items.ENDER_PEARL, Items.IRON_SWORD, Items.GOLDEN_APPLE, Items.DIAMOND};
    static final Item[] OBS_LOOT = {Items.OBSIDIAN, Items.EMERALD, Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.DIAMOND,
            Items.DIAMOND_SWORD, Items.TOTEM_OF_UNDYING, Items.ENCHANTED_GOLDEN_APPLE, Items.NETHERITE_INGOT};
    static final Item[] JUNK = {Items.ROTTEN_FLESH, Items.STICK, Items.ARROW, Items.COAL, Items.BONE, Items.STRING, Items.COBWEB};

    // ===== Rai rac theo nguoi choi =====
    /** Goi moi 2 giay. Xay can cu moi khi nguoi choi den gan o luoi chua xu ly. */
    static void scatterTick(MinecraftServer s) {
        ServerWorld w = s.getOverworld();
        if (DonutLike.save.baseCells == null) DonutLike.save.baseCells = new HashSet<>();
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            if (p.getWorld() != w) continue;
            int cx0 = Math.floorDiv(p.getBlockX(), CELL), cz0 = Math.floorDiv(p.getBlockZ(), CELL);
            for (int cx = cx0 - 1; cx <= cx0 + 1; cx++) {
                for (int cz = cz0 - 1; cz <= cz0 + 1; cz++) {
                    String key = cx + "," + cz;
                    if (DonutLike.save.baseCells.contains(key)) continue;
                    Random r = new Random(w.getSeed() * 31L + cx * 341873128712L + cz * 132897987541L);
                    int bx = cx * CELL + 24 + r.nextInt(CELL - 48);
                    int bz = cz * CELL + 24 + r.nextInt(CELL - 48);
                    double dx = bx - p.getX(), dz = bz - p.getZ();
                    if (dx * dx + dz * dz > (double) TRIGGER_DIST * TRIGGER_DIST) continue;
                    DonutLike.save.baseCells.add(key); // danh dau da xu ly (co base hay khong)
                    if (r.nextDouble() > BASE_CHANCE) continue;
                    if (Math.abs(bx) < 64 && Math.abs(bz) < 64) continue; // khong xay sat spawn
                    Style st = randomStyle(r);
                    boolean raided = r.nextDouble() < (st == Style.OBSIDIAN ? 0.30 : 0.50);
                    tryPlace(w, bx, bz, st, raided, r);
                }
            }
        }
    }

    static Style randomStyle(Random r) {
        double d = r.nextDouble();
        return d < 0.55 ? Style.WOOD : d < 0.85 ? Style.STONE : Style.OBSIDIAN;
    }

    // ===== Sinh 1 can cu gan 1 vi tri (dung cho /randombase va su kien dinh ky) =====
    /** raidedOpt: null = ngau nhien, true = bi raid, false = nguyen ven. */
    static Result spawnNear(ServerWorld w, BlockPos origin, int minD, int maxD, Boolean raidedOpt) {
        Random r = DonutLike.R;
        for (int attempt = 0; attempt < 8; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2;
            int d = minD + r.nextInt(Math.max(1, maxD - minD));
            int x = origin.getX() + (int) (Math.cos(ang) * d);
            int z = origin.getZ() + (int) (Math.sin(ang) * d);
            Style st = randomStyle(r);
            boolean raided = raidedOpt != null ? raidedOpt : r.nextDouble() < (st == Style.OBSIDIAN ? 0.30 : 0.50);
            Result res = tryPlace(w, x, z, st, raided, r);
            if (res != null) return res;
        }
        return null;
    }

    static int half(Style st) { return st == Style.STONE ? 4 : 3; }

    /** Tim cho bang phang, khong nuoc roi xay. Tra null neu dia hinh khong hop. */
    static Result tryPlace(ServerWorld w, int x, int z, Style st, boolean raided, Random r) {
        int h = half(st);
        w.getChunk(x >> 4, z >> 4);
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        int min = y, max = y;
        int[][] pts = {{h, h}, {h, -h}, {-h, h}, {-h, -h}};
        for (int[] pt : pts) {
            int px = x + pt[0], pz = z + pt[1];
            w.getChunk(px >> 4, pz >> 4);
            int ty = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, px, pz);
            min = Math.min(min, ty); max = Math.max(max, ty);
            if (!w.getFluidState(new BlockPos(px, ty - 1, pz)).isEmpty()) return null;
        }
        if (max - min > 5) return null;
        if (!w.getFluidState(new BlockPos(x, y - 1, z)).isEmpty()) return null;
        if (y <= w.getSeaLevel() - 1) return null;
        BlockPos c = new BlockPos(x, y, z);
        build(w, c, st, raided, r);
        return new Result(c, st, raided);
    }

    // ===== Xay can cu =====
    static void build(ServerWorld w, BlockPos c, Style st, boolean raided, Random r) {
        int h = half(st);
        int wallH = st == Style.STONE ? 6 : 3;
        int roofY = wallH + 1;
        Block baseWall = switch (st) {
            case WOOD -> pick(r, Blocks.OAK_PLANKS, Blocks.SPRUCE_PLANKS, Blocks.BIRCH_PLANKS);
            case STONE -> Blocks.STONE_BRICKS;
            case OBSIDIAN -> Blocks.OBSIDIAN;
        };
        double holeP = raided ? (st == Style.OBSIDIAN ? 0.06 : 0.28) : 0;
        double roofHoleP = raided ? (st == Style.OBSIDIAN ? 0.04 : 0.20) : 0;

        // 1) don dep thể tich phia tren (cay, la, dat cao) + nen mong
        for (int dx = -h - 1; dx <= h + 1; dx++)
            for (int dz = -h - 1; dz <= h + 1; dz++) {
                for (int dy = 0; dy <= roofY + 4; dy++) DonutLike.set(w, c.add(dx, dy, dz), Blocks.AIR);
                if (Math.abs(dx) <= h && Math.abs(dz) <= h)
                    for (int dy = -6; dy <= -1; dy++)
                        DonutLike.set(w, c.add(dx, dy, dz),
                                raided && r.nextDouble() < 0.3 ? Blocks.MOSSY_COBBLESTONE : Blocks.COBBLESTONE);
            }

        // 2) tuong + cua so + mai
        for (int dx = -h; dx <= h; dx++)
            for (int dz = -h; dz <= h; dz++) {
                boolean edge = Math.abs(dx) == h || Math.abs(dz) == h;
                boolean corner = Math.abs(dx) == h && Math.abs(dz) == h;
                for (int dy = 0; dy <= wallH; dy++) {
                    if (!edge) continue;
                    boolean door = dx == 0 && dz == -h && dy <= 1;
                    if (door) continue;
                    if (raided && dy >= 1 && r.nextDouble() < holeP) continue; // tuong bi dap thung
                    boolean window = st != Style.OBSIDIAN && !corner && dy % 3 == 1 && Math.floorMod(dx + dz, 2) == 1;
                    if (window) {
                        if (raided && r.nextDouble() < 0.6) continue; // kinh vo
                        DonutLike.set(w, c.add(dx, dy, dz), Blocks.GLASS_PANE);
                    } else {
                        DonutLike.set(w, c.add(dx, dy, dz), wallBlock(st, baseWall, raided, r));
                    }
                }
                if (!(raided && r.nextDouble() < roofHoleP))
                    DonutLike.set(w, c.add(dx, roofY, dz), wallBlock(st, baseWall, raided, r));
            }

        // 3) tang 2 + thang (chi kieu STONE)
        if (st == Style.STONE) {
            for (int dx = -h + 1; dx <= h - 1; dx++)
                for (int dz = -h + 1; dz <= h - 1; dz++) {
                    if (dx == h - 1 && dz == h - 1) continue; // lo thang
                    if (raided && r.nextDouble() < 0.15) continue;
                    DonutLike.set(w, c.add(dx, 3, dz), Blocks.OAK_PLANKS);
                }
            for (int dy = 0; dy <= 4; dy++) DonutLike.set(w, c.add(h - 1, dy, h - 1), Blocks.LADDER);
        }

        // 4) noi that
        int e = h - 1;
        if (!raided || r.nextBoolean()) DonutLike.set(w, c.add(-e, 0, -e), Blocks.CRAFTING_TABLE);
        if (!raided || r.nextBoolean()) DonutLike.set(w, c.add(e, 0, -e), Blocks.FURNACE);
        if (!raided || r.nextDouble() < 0.25) {
            DonutLike.set(w, c.add(e, 0, 0), Blocks.TORCH);
            DonutLike.set(w, c.add(-e, 0, 0), Blocks.TORCH);
            if (st == Style.STONE) {
                DonutLike.set(w, c.add(e, 4, 0), Blocks.TORCH);
                DonutLike.set(w, c.add(-e, 4, 0), Blocks.TORCH);
            }
        }

        // 5) ruong
        Item[] loot = st == Style.WOOD ? WOOD_LOOT : st == Style.STONE ? STONE_LOOT : OBS_LOOT;
        java.util.List<BlockPos> spots = new java.util.ArrayList<>();
        spots.add(c.add(-e, 0, e));
        spots.add(c.add(0, 0, e));
        if (st == Style.STONE) { spots.add(c.add(-e, 4, e)); spots.add(c.add(0, 4, e)); spots.add(c.add(-e, 4, -e)); }
        int nChest = switch (st) { case WOOD -> 1 + r.nextInt(2); case STONE -> 2 + r.nextInt(3); case OBSIDIAN -> 2 + r.nextInt(2); };
        java.util.Collections.shuffle(spots, r);
        for (int i = 0; i < Math.min(nChest, spots.size()); i++) {
            BlockPos cp = spots.get(i);
            if (raided) {
                double roll = r.nextDouble();
                if (roll < 0.40) continue;            // ruong bi lay mat luon
                chest(w, cp, JUNK, r.nextInt(3), r);  // chi con rac
                if (roll > 0.85) chestAdd(w, cp, loot, 1, r); // thinh thoang sot lai 1 mon
            } else {
                chest(w, cp, loot, 3 + r.nextInt(st == Style.OBSIDIAN ? 6 : 5), r);
            }
        }

        // 6) hieu ung raid: ho bom, mang nhen, vun
        if (raided) {
            if (st != Style.OBSIDIAN && r.nextDouble() < 0.5) {
                int sx = r.nextBoolean() ? h : -h, sz = r.nextBoolean() ? h : -h;
                for (int dx = -2; dx <= 2; dx++)
                    for (int dy = -1; dy <= 3; dy++)
                        for (int dz = -2; dz <= 2; dz++) {
                            if (dx * dx + dy * dy + dz * dz > 5) continue;
                            BlockPos p = c.add(sx + dx, 1 + dy, sz + dz);
                            if (w.getBlockState(p).isOf(Blocks.CHEST)) continue;
                            DonutLike.set(w, p, Blocks.AIR);
                        }
            }
            for (int i = 0; i < 14; i++) {
                BlockPos p = c.add(r.nextInt(2 * e + 1) - e, r.nextInt(3), r.nextInt(2 * e + 1) - e);
                if (w.getBlockState(p).isAir()) DonutLike.set(w, p, Blocks.COBWEB);
            }
            for (int dx = -h - 2; dx <= h + 2; dx++)
                for (int dz = -h - 2; dz <= h + 2; dz++) {
                    if (Math.abs(dx) <= h && Math.abs(dz) <= h) continue;
                    double d = r.nextDouble();
                    if (d < 0.18) DonutLike.set(w, c.add(dx, -1, dz), Blocks.COARSE_DIRT);
                    else if (d < 0.26) DonutLike.set(w, c.add(dx, -1, dz), Blocks.NETHERRACK);
                }
        }
    }

    static Block wallBlock(Style st, Block base, boolean raided, Random r) {
        if (raided && st == Style.STONE) {
            double d = r.nextDouble();
            return d < 0.30 ? Blocks.CRACKED_STONE_BRICKS : d < 0.50 ? Blocks.MOSSY_STONE_BRICKS : base;
        }
        return base;
    }

    static Block pick(Random r, Block... bs) { return bs[r.nextInt(bs.length)]; }

    /** Dat ruong va do n mon (mon hiem o cuoi mang, de ra it hon). */
    static void chest(ServerWorld w, BlockPos p, Item[] loot, int n, Random r) {
        DonutLike.set(w, p, Blocks.CHEST);
        chestAdd(w, p, loot, n, r);
    }

    static void chestAdd(ServerWorld w, BlockPos p, Item[] loot, int n, Random r) {
        if (!(w.getBlockEntity(p) instanceof ChestBlockEntity ch)) return;
        for (int i = 0; i < n; i++) {
            Item it = loot[Math.min(r.nextInt(loot.length), r.nextInt(loot.length))];
            int cnt = Math.min(it.getMaxCount(), 1 + r.nextInt(5));
            ch.setStack(r.nextInt(27), new ItemStack(it, cnt));
        }
    }
}
